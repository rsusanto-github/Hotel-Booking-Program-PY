# CPSC 463 - Project 2
A hotel management service implemented in python
## Authors
- Cody Mangham
- Robert Susanto
- Evan Delasota 
- Scott Park

## Running the code
The code is hosted [here on replit](https://replit.com/@robert061298/463-PROJECT-2-PY?v=1)

Press the big button at the top that says run, or run 'python init_db.py' and then 'python main.py'

## Libraries used
- [Tabulate](https://pypi.org/project/tabulate/)
- [Faker Python](https://pypi.org/project/Faker/)
- [sqlite3](https://www.sqlite.org/index.html)
- [sqlite_utils](https://pypi.org/project/sqlite-utils/)