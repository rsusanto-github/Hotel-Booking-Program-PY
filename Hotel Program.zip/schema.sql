CREATE TABLE [Room] (
   [room_id] INTEGER PRIMARY KEY,
   [room_type] TEXT,
   [room_price] FLOAT,
   [availability] TEXT
);
CREATE TABLE [Guest] (
   [guest_id] INTEGER PRIMARY KEY,
   [first_name] TEXT,
   [last_name] TEXT,
   [email] TEXT,
   [id_num] TEXT,
   [state] TEXT,
   [address] TEXT,
   [plate_num] TEXT
);
CREATE TABLE [Reservation] (
   [reservation_id] INTEGER PRIMARY KEY,
   [room_id] INTEGER REFERENCES [Room]([room_id]),
   [guest_id] INTEGER REFERENCES [Guest]([guest_id]),
   [date_made] TEXT,
   [date_start] TEXT,
   [date_end] TEXT,
   [website] TEXT,
   [total] FLOAT
);
CREATE TABLE [Housekeeper] (
   [housekeeper_id] INTEGER PRIMARY KEY,
   [first_name] TEXT,
   [last_name] TEXT
);
CREATE TABLE [Cleaning] (
   [housekeeper_id] INTEGER REFERENCES [Housekeeper]([housekeeper_id]),
   [room_id] INTEGER REFERENCES [Room]([room_id]),
   [bathroom] INTEGER,
   [towels] INTEGER,
   [bed_sheets] INTEGER,
   [vacuum] INTEGER,
   [dusting] INTEGER,
   [electronics] INTEGER,
   PRIMARY KEY ([housekeeper_id], [room_id])
);
CREATE TABLE [Stay] (
   [reservation_id] INTEGER REFERENCES [Reservation]([reservation_id]),
   [balence] FLOAT,
   [payments_made] FLOAT
);
