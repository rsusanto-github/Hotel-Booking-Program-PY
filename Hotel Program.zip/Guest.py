import sqlite3
from sqlite_utils import Database
db = Database(sqlite3.connect("share/hotel.db"))

class Current_Guest:
    first_name = ""
    last_name = ""
    guest_id = 0

    @staticmethod
    def check_in_with_name(self,first,last):
        for guest in db["Guest"].rows_where("first_name = ? last_name= ?",[first,last],select="guest_id"):
          self.guest_id = guest["guest_id"]
        if self.guest_id == 0:
          print(f"Could not find guest with name: {first} {last}")
          self.first_name=self.last_name = ''
        else:
          self.first_name,self.last_name = first,last

    def check_in_with_id(self,guest_id):
        try:
          guest = db["Guest"].get(guest_id)
          self.first_name, self.last_name = guest['first_name'],guest['last_name']
          self.guest_id = guest_id
        except:
          print(f"Could not find user with id: {guest_id}")

    @staticmethod
    def log_in(self):
      print('1. Returning Guest')
      print('2. New Guest')
      print('0. Cancel')
      choice = input(' >> ')
      if choice == '1':
        self.check_in_with_name(input("Enter First Name: "), input("Enter Last Name: "))
        if self.is_checked_in():
          print("User is not checked in")
      elif choice == '2':
        self.register_guest()

    


    def is_checked_in(self):
      return self.guest_id != 0
      

    def checkout_guest(self):
      self.first_name = ''
      self.last_name = ''
      self.guest_id = 0


    def register_guest(self):
      first_name,last_name = input("Please Enter First name: "),input("Please Enter Last Name")
      try:
          row = {
            "first_name": first_name,
            "last_name": last_name,
            "email": input("Please Enter Email: "),
            "id_num": input("Please Enter Valid ID (Drivers License, StateID etc.): "),
             "address": input("Please Stress address: "),
            "state": input("Please Enter State CODE ex. CA: "),
            "plate_num":input("Please License Plate Number: ")
          }
          db["Guest"].insert(row)
          self.first_name, self.last_name = first_name,last_name 
          self.guest_id = db["Guest"].last_pk
      except:
          print("Error could not create new guest")

    @staticmethod
    def get_full_guest_info(self):
        if self.guest_id:
            return db["Guest"].get(self.guest_id)
        else:
            return False

    @staticmethod
    def get_id(self):
      return self.guest_id
    
        

    

