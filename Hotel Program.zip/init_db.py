import sqlite3
import faker
from sqlite_utils import Database
import random
from datetime import datetime, timedelta

db = Database(sqlite3.connect("share/hotel.db"))
fake = faker.Faker()


def initialize_db():
    db['Room'].create(
      {
          "room_id": int,
          "room_type": str,
          "room_price": float,
          "availability": str
      },
      pk="room_id")

    db['Guest'].create(
        {
            "guest_id": int,
            "first_name": str,
            "last_name": str,
            "email": str,
            "id_num": str,
            "state": str,
            "address": str,
            "plate_num": str,
        },
        pk="guest_id")

    db['Reservation'].create(
        {
            "reservation_id": int,
            "room_id": int,
            "guest_id": int,
            "date_made": str,
            "date_start": str,
            "date_end": str,
            "website": str,
            "total": float
        },
        pk="reservation_id",
        foreign_keys=["room_id", "guest_id"])

    db['Stay'].create(
        {
            "reservation_id": int,
            "balence": float,
            "payments_made": float
        },
        foreign_keys=["reservation_id"])

    db['Housekeeper'].create(
        {
            "housekeeper_id": int,
            "first_name": str,
            "last_name": str,
        },
        pk="housekeeper_id")

    db['Cleaning'].create(
        {
            "housekeeper_id": int,
            "room_id": int,
            "bathroom": bool,
            "towels": bool,
            "bed_sheets": bool,
            "vacuum": bool,
            "dusting": bool,
            "electronics": bool
        },
        pk=("housekeeper_id", "room_id"),
        foreign_keys=["housekeeper_id", "room_id"])


def get_fake_date():
    start_date = datetime(2020, 1, 1)
    end_date = datetime(2022, 12, 29)
    return fake.date_between_dates(start_date, end_date)


def fill_room_db():
    status = ["AVAILABLE", "OCCUPIED", "DIRTY", "UNDER MATINENCE"]
    room_types = ["KING", "QUEEN", "DOUBLE QUEEN WITH KITCHEN", "DOUBLE QUEEN"]
    prices = [
        random.uniform(300, 400),
        random.uniform(200, 250),
        random.uniform(450, 500),
        random.uniform(300, 400)
    ]
    index_arr = [i for i in range(4)]
    fake_data = []
    for i in range(1, 201):
        row = {}
        random_num = random.choices(index_arr, weights=[2, 4, 1, 2])[0]
        row = {
            "room_id": i,
            "room_type": room_types[random_num],
            "room_price": round(prices[random_num], 2),
            "availability": random.choices(status, weights=[4, 4, 2, 1])[0]
        }
        fake_data.append(row)
    db["Room"].insert_all(fake_data)


def fill_guest_db():
    fake_data = []

    for i in range(1, 101):
        row = {}
        row = {
            "guest_id":
            i,
            "first_name":
            fake.first_name(),
            "last_name":
            fake.last_name(),
            "email":
            fake.free_email(),
            "id_num":
            "".join([chr(random.randint(60, 90)) for _ in range(2)] +
                    [str(random.randint(100_000_000, 999_999_999))]),
            "state":
            fake.state_abbr(include_territories=False),
            "address":
            fake.street_address(),
            "plate_num":
            fake.license_plate(),
        }
        fake_data.append(row)
    db["Guest"].insert_all(fake_data)


def fill_housekeeper_db():
    fake_data = []
    for i in range(1, 20):
        row = {}
        row = {
            "housekeeper_id": i,
            "first_name": fake.first_name(),
            "last_name": fake.last_name(),
        }
        fake_data.append(row)
    db["Housekeeper"].insert_all(fake_data)


def fill_cleaning_db(dirty_room_ids):
    fake_data = []
    for i in dirty_room_ids:
        row = {}
        row = {
            "housekeeper_id": random.randint(1, 20),
            "room_id": i,
            "bathroom": random.randint(0, 1),
            "towels": 1,
            "bed_sheets": random.randint(0, 1),
            "vacuum": random.randint(0, 1),
            "dusting": random.randint(0, 1),
            "electronics": random.randint(0, 1),
        }
        fake_data.append(row)
    db["Cleaning"].insert_all(fake_data)


def fill_reservation_db():
    fake_data = []

    hotel_websites = [
        "Kayak", "Expedia", "Priceline", "Momondo", "Booking.com",
        "Hotels.com", "Orbitz", "Trivago"
    ]
    for i in range(1, 1000):
        row = {}
        date_made = get_fake_date()  #datetime obj
        date_checkin = date_made + timedelta(days=(random.randint(3, 14)))
        date_checkout = date_checkin + timedelta(days=(random.randint(3, 10)))
        rate = round(random.uniform(100, 500), 2)
        row = {
            "reservation_id": i,
            "room_id": random.randint(1, 200),
            "guest_id": random.randint(1, 100),
            "date_made": date_made,
            "date_start": date_checkin,
            "date_end": date_checkout,
            "website": random.choice(hotel_websites),
            "total": round(rate * random.randint(3, 7), 2)
        }
        fake_data.append(row)
    db["Reservation"].insert_all(fake_data)


if __name__ == "__main__":
    initialize_db()
    fill_room_db()
    fill_guest_db()
    fill_reservation_db()
    fill_housekeeper_db()
    dirty_rooms = []
    for x in db["Room"].rows_where("availability = \"DIRTY\""):
        dirty_rooms.append(x['room_id'])
    fill_cleaning_db(dirty_rooms)
    print(db.schema)
    pass
