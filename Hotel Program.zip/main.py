import sqlite3
import sys
import os
from tabulate import tabulate
from sqlite_utils import Database
from Guest import Current_Guest
from datetime import date, datetime, timedelta


# The connection to the Database that is used
db = Database(sqlite3.connect("share/hotel.db"))


def main_menu():
  os.system('clear')

  print('Enter an option below:')
  print('1. Show a room and its current status')
  print('2. Show who is staying at which room for the next week')
  print('3. List of current reservations')
  print('4. Housekeeping list')
  print('5. Show guest profile')
  print('6. Show guest information and their current stay')
  print('7. Guest search')
  print('8. Daily report')
  print('0. Exit')
  choice = input(" >> ")
  exec_menu(choice)
  return

def exec_menu(choice):
  os.system('clear')
  
  if choice == '':
    menu_actions['main_menu']()
  else:
    try:
      menu_actions[choice]()
    except KeyError:
      print("Invalid input, try again!\n\n")
      menu_actions['main_menu']() 


def menu1():
  
  table = []
  # SQL QUERY
  for row in db.query("SELECT room_id, availability FROM Room"):
    table.append(list(row.values()))
  print(tabulate(table,headers=["Room Number","Availability"],tablefmt='pretty'))
  print('-1. Back')
  print('0. Exit')
  room_choice = int(input("Which room would you like to choose? >> "))


  while room_choice < 1 or room_choice > len(table):
    print("Choice out of range, please try again")
    room_choice = int(input("Which room would you like to choose? >> "))
  

  current_availability = table[room_choice-1][1].lower()
  if  current_availability == "available":
    check_in = input("Room is avaialable, would you like to reserve it? (Y / N):")
    if check_in.lower() == "Y" or check_in.lower() == "yes":
        menu6_rsvp(f_name = None, l_name = None, room_number = room_choice)
    else:
      pass
  elif current_availability == "occupied":
    menu6_print(f_name = None, l_name = None, room_number = room_choice)
    if not Current_Guest.is_checked_in():
      db["Room"].update(room_choice,{"availability":"DIRTY"})
  elif current_availability == "dirty" or current_availability == "under_matinence": # these have very similar descriptios
    make_avaiable = input("Would you like to make this room available? (Y / N):")
    if make_avaiable.lower() == "y" or make_avaiable.lower() == "yes":
      try:
        db["Room"].update(room_choice,{"availability":"AVAILABLE"})
      except:
        print("Could not remove room")
    elif make_avaiable.lower() == "n" or make_avaiable.lower() == "no":
      pass
  exec_menu(room_choice)
  return


def menu2():
  table = []

  room_numbers = []
  for row in db['Room'].rows_where(select="room_id"):
    room_numbers.append(row["room_id"])

  seven_days = []
  day_content = []
  count = 1
  while count < 8:
    query = """
            SELECT Room.room_id, (Guest.first_name || " " || Guest.last_name)
            FROM Room LEFT JOIN Reservation on Room.room_id = Reservation.room_id LEFT JOIN  Guest on Reservation.guest_id = Guest.guest_id
            WHERE date(%s) BETWEEN Reservation.date_start AND Reservation.date_end
            """ % ("""'now', '+""" + str(count) + """ day'""")
    for row in db.query(query):
      day_content.append(row)
    seven_days.append(day_content)
    day_content = []
    count += 1


  for room in room_numbers:
    day_array = []
    for day in seven_days:
      item_list = ""
      for item in day:
        if item["room_id"] == room:
          item_list = item["""(Guest.first_name || " " || Guest.last_name)"""]
      if item_list == "":
        day_array.append("")
      else:
        day_array.append(item_list)
    table.append([room, day_array[0], day_array[1], day_array[2], day_array[3] , day_array[4], day_array[5], day_array[6]])
  next_seven_days = [ date.today()+timedelta(days=i) for i in range(1,8) ]
  print(tabulate(table,headers=(["Room Number"]+next_seven_days), tablefmt="pretty"))

  room_select = int(input("\nTo check guest information, or to add a reservation, please enter the room number.\nOtherwise, enter 0 to return to main menu: "))

  if room_select > 0 and room_select < 201:
    current_name = ""
    rsvp_name = []
    rsvp_exist = False
    empty_day_exist = False
    for item in table[room_select-1]:
      if(item != "" and str(item).isnumeric() == False):
        rsvp_exist = True
        if(item != current_name):
          rsvp_name.append(item)
        current_name = item
      elif item == "":
        empty_day_exist = True
        
    if rsvp_exist == True:
      if empty_day_exist == True:
        ask_user = input("Would you like to make a Reservation or obtain information on current Guest?\n1. Make Reservation\n2. Guest Information: ")
        print(ask_user)
        if ask_user == '1':
          print("Create Reservation")
          rsvp_date = input("Is the reservation for today or for a future date?(today/future): ")
          if rsvp_date == "today" or rsvp_date == "t":
            menu6_rsvp(f_name = None, l_name = None, room_number = table[room_select-1][0])
          elif rsvp_date == "future" or rsvp_date == "f":
            menu3()
        elif ask_user == '2':
        # If there are more than one Guest booked in the 7 days:
          if len(rsvp_name) > 2:
            print("Please select which guest you would like information for: ")
            count = 1
            for user in rsvp_name:
              print(str(count) + ". " + user)
              count += 1
            user_input = input(">>")
            user_name = rsvp_name[user_input-1].split()
            menu6_print(user_name[0], user_name[1])
          else:
          # Only 1 Guest booked
            user_name = rsvp_name[0].split()
            menu6_print(user_name[0], user_name[1])
        else:
          print("Please enter the correct value.")
          input("Press enter to continue >>")
          menu2()
      else:
        if len(rsvp_name) > 2:
          print("Please select which guest you would like information for: ")
          count = 1
          for user in rsvp_name[1:]:
            print(str(count) + ". " + user)
            count += 1
          user_input = input(">>")
          user_name = rsvp_name[user_input-1].split()
          menu6_print(user_name[0], user_name[1])
        else:
          # Only 1 Guest booked
          user_name = rsvp_name[0].split()
          menu6_print(user_name[0], user_name[1])
    else:
      # No Guest Booked
      print("Create Reservation")
      rsvp_date = input("Is the reservation for today or for a future date?(today/future): ")
      if rsvp_date == "today" or rsvp_date == "t":
        # menu6_rsvp(f_name=None, None, table[room_select-1][0])
        pass
      elif rsvp_date == "future" or rsvp_date == "f":
        menu3()
      


def menu3():
  table = []
  for reservation in db["Reservation"].rows_where('date_start >= :today or date_end >= :today', 
                                                  {'today':date.today()},
                                                  select="reservation_id, guest_id, room_id, date_start, date_end"):
      res_guest = db["Guest"].get(reservation['guest_id'])
      reservation['guest_id'] = f"{res_guest['first_name']} {res_guest['last_name']}"
      table.append(list(reservation.values()))


  print(tabulate(table,headers=["Resrvation ID", "Guest Name","Room Number", "Check-In Date","Check-Out Date"],tablefmt="pretty"))
  print('1. Add Reservation')
  print('2. Delete Reservation')
  print('9. Back')
  print('0. Exit')
  choice = int(input(' >> '))
  if choice == 1:
    room_table = [ list(room.values()) for room in db['Room'].rows_where('availability = ?',['AVAILABLE'],select="room_id,room_type,room_price",order_by="room_type")]
    print(tabulate(room_table,headers=["Room Number", "Room Type","Price"], tablefmt="pretty"))
    res_room_id = input("Which Room would you like to Reserve (Room Number): ")
    if Current_Guest.is_checked_in():
      menu6_rsvp(room_number=res_room_id,guest_id=Current_Guest.get_id())
    else:
      #  menu6_rsvp(room_number
      pass
       
  elif choice == 2:
    del_room_id = input("Which Reservation would you like to Delete (Resrvation ID): ")
    try:
      db['Reservation'].delete(del_room_id)
      print("Removed Reservation")
    except:
      print('Could not delete this reservation')
    

def menu4():
  cleaning_query = """SELECT
        R.room_id,
        R.availability,
        (H.first_name || " " || H. last_name),
        C.bathroom,
        C.towels,
        C.bed_sheets,
        C.vacuum,
        C.dusting,
        C.electronics
    FROM
        Housekeeper H,
        Room R NATURAL JOIN Cleaning C
    WHERE
        C.housekeeper_id = H.housekeeper_id"""
  table = []
  for row in db.query(cleaning_query):
    first_part = list(row.values())[:3] 
    second_part = ", ".join([key for key,val in row.items() if val == 1 and key != 'room_id'])
    table.append(first_part+[second_part])


  for row in db["Room"].rows_where("availability = 'OCCUPIED'",select="room_id"):
    table.append([row['room_id'],'OCCUPIED',"N/A",""])
  table.sort(key=(lambda x: x[0]))
  print(tabulate(table,headers=["Room Number", "Availability","Housekeeper","Neccesary Cleaning"],tablefmt="pretty"))


  print('9. Back')
  print('0. Exit')
  choice = input(' >> ')
  exec_menu(choice)
  return

edit_actions = {
  '1' : 'first_name',
  '2' : 'last_name',
  '3' : 'address',
  '4' : 'email',
  '5' : 'id_num',
  '6' : 'plate_num',
  '7' : 'state',
}

def edit_information(selection, guest_id):
  new_value = input(f'Enter new {selection}: ')
  db.execute(f"UPDATE Guest SET {selection} = \"{new_value}\" WHERE guest_id = {guest_id}")
  db.commit()
  print('Information updated, returning...')
  menu5_edit(guest_id)
  
def menu5_edit(guest_id):
  print('Enter field you would like to edit: ')
  print('1. First Name')
  print('2. Last Name')
  print('3. Address')
  print('4. Email Address')
  print('5. Id Number')
  print('6. License Plate')
  print('7. State')
  print('9. Back')
  print('0. Exit')
  choice = input(' >> ')
  if choice == 9:
    exec_menu(5)
  elif choice == 0:
    exec_menu(0)
  else:
    edit_information(edit_actions[choice], guest_id)
  return

def menu5():
  print('Enter first and last name to log in')
  first_name = input('First name: ')
  last_name = input('Last name: ')
  os.system('clear')
  
  print('Current profile information')
  for row in db.query("SELECT * FROM Guest WHERE first_name = ? AND last_name = ?", (first_name, last_name)):
#   print(row)
    guest_id = row["guest_id"]
#  print(guest_id)
  guest_info = db["Guest"].get(guest_id)
  table = []
  for key,val in guest_info.items():
    table.append([key,val])
  print(tabulate(table,headers=["Column","Info"],tablefmt="pretty"))
  print('Enter "e" to edit')
  print('9. Back')
  print('0. Exit')
  choice = input(' >> ')
  if (choice.lower() == 'e'):
    menu5_edit(guest_id)
    return  
  else:
    exec_menu(choice)
    return

def menu6():
  print("Enter guest information: ")
  f_name = input("Enter first name: ")
  l_name = input("Enter last name: ")
  menu6_print(f_name=f_name, l_name=l_name)
  return

def menu6_rsvp(guest_id=None,f_name = None, l_name = None, room_number = None, check_in_date = None, check_out_date = None):
  if not Current_Guest.is_checked_in():
    if f_name is None:
      user_input = input("Put in first name: ")
      f_name = user_input
    if l_name is None:
      user_input = input("Put in last name: ")
      l_name = user_input
    Current_Guest.check_in_with_name(f_name,l_name)
    if room_number is None:
      user_input = input("Put in room number: ")
      room_number = user_input
    if check_in_date is None:
      user_input = input("Put in check-in date (yyyy-mm-dd): ")
      check_in_date = user_input
    if check_out_date is None:
      user_input = input("Put in check-out date (yyyy-mm-dd): ")
      check_out_date = user_input
    
  if guest_id is None:
     guest_id = Current_Guest.get_id()
    # for row in db["Guest"].rows_where("first_name = ? AND last_name = ?",[f_name,l_name], select="guest_id"):
    #   guest_id = row["guest_id"]

  rate = float(db["Room"].get(room_number)["room_price"])
  check_in_date = datetime.strptime(check_in_date,'%Y-%m-%d')
  check_out_date = datetime.strptime(check_out_date,'%Y-%m-%d')
  duration = check_out_date - check_in_date
  total = -(rate * duration.days)
  try:
    db["Reservation"].insert({
      "room_id": room_number,
      "guest_id": guest_id,
      "date_made": str(date.today()), 
      "date_start": check_in_date, 
      "date_end": check_out_date, 
      "total": total
    })
    print("Reservation Creation Success.")
    db["Room"].update(room_number,{"availability":"OCCUPIED"})
  except Exception as e:
    print(f"Could not create Reservation: {e}")
  input("Press enter to view current stay...")
  menu6_print(f_name = f_name, l_name = l_name, room_number = room_number)



def menu6_print(guest_id=None, f_name = None, l_name = None, room_number = None):
  if not(guest_id or f_name or l_name):
    return
  query = """
        SELECT Guest.first_name, Guest.last_name, Reservation.reservation_id
        Reservation.date_start, Reservation.date_end, Reservation.reservation_id, 
        Room.room_type, Room.room_id, Room.room_price, Room.availability, Stay.payments_made, Stay.balence 
        FROM Guest LEFT JOIN Reservation on Guest.guest_id = Reservation.guest_id 
        LEFT JOIN Room on Reservation.room_id = Room.room_id 
        LEFT JOIN Stay on Reservation.reservation_id = Stay.reservation_id 
        WHERE (Guest.first_name = "%s"  
        AND Guest.last_name = "%s")""" % (f_name, l_name)
  if room_number:
    query += f' OR (\'{room_number}\' = Room.room_id) '
  guest_info =  []
  for row in db.query(query):
    guest_info.append(row)
  if guest_info == []:
    print("This user does not exist, or does not have any reservation info within the next 7 days.")
    print("What would you like to do?")
    print("1. Search For User")
    print("2. Create New Reservation For This User")
    print('9. Back')
    print('0. Exit')
    choice = input(' >> ')
    if choice == '1':
      menu7()
    elif choice == '2':
      menu6_rsvp(f_name, l_name, room_number)
    else:
      exec_menu(choice)
  else:
    for row in db.query("""SELECT julianday('%s') - julianday('%s')"""%(guest_info[0] ["date_start"],guest_info[0]["date_end"])):
      date_diff = row
    date_diff_statement = """julianday('%s') - julianday('%s')""" % (guest_info[0]  ["date_start"],guest_info[0]["date_end"])
    total_charge = -(float(guest_info[0]["room_price"]) * float(date_diff [date_diff_statement]))
    if(guest_info[0]["payments_made"] == None or 0):
      payments_made = 0
    balance_remaining = total_charge + (float(guest_info[0]["room_price"]) *  payments_made)

    def print_info():
      table = []
      print("Guest Information: ")
      check_in = guest_info[0]["date_start"]
      table.append([f"Check In: {check_in}", "Check In Time:\t1:00PM"])
      table.append([f"Check Out: {guest_info[0]['date_end']}", "Expected Check Out Time:\t11:00AM"])
      table.append([f"Room Type: {guest_info[0]['room_type']}"  , f"Room Number: {guest_info[0]['room_id']}"])
      table.append([f"Room Rate: ${guest_info[0]['room_price']}/Day", f"Total Charge: ${total_charge:.2f}"])
      table.append([f"Payments Made: {guest_info[0]['payments_made']}", f"Balance: {balance_remaining:.2f}"])
      print(tabulate(table))
    
    print_info() 
    print("1. Make Payments")
    print("2. Create New Reservation For This User")
    print("3. Check-Out Guest")
    print("4. Extend Stay")
    print('9. Back')
    print('0. Exit')
    choice = input(">>")
    if choice == '1':
      current_payment = float(input("How much would you like to pay?(-1 to cancel): "))
      if current_payment != -1.0:
        balance_remaining = 0.0 if current_payment >= balance_remaining else balance_remaining - current_payment
        print("Payment Made!")
        print_info()
      else:
        exec_menu(1)
    elif choice == '2':
      menu6_rsvp(f_name = f_name, l_name = l_name)
    elif choice == '3':
      if guest_info[0]["availability"] == "DIRTY" or guest_info[0]["availability"] == "UNDER MATINENCE":
        print("Guest already checked out.")
        menu6_print(f_name, l_name)
      else:
        db.execute("UPDATE Room SET availability = 'Dirty'")
        db.commit()
        print("Guest checked-out successfully.")
        menu6_print(f_name, l_name)
    elif choice == '4':
      new_check_out_day = input("When would you like to check out? (yyyy-mm-dd): ")
      new_check_out_day = datetime.strptime(new_check_out_day,'%Y-%m-%d')
      db["Reservation"].update()
    else:
      exec_menu(choice)


def menu6_edit_current_stay(room_number):
  
  pass
def menu7():
  table = []
  #first = type(str)
  #last = type(str)
  print('Welcome to the search screen, Press 1 to start')
  print('1. Start')
  print('9. Back')
  print('0. Exit')
  choice = input(' >> ')
  if int(choice) == 1:
    name = input('Enter name to search: ')
    query = ("SELECT G.guest_id,G.first_name, G.last_name, R.room_id, "
    "R.date_start, R.date_end FROM Guest as G NATURAL JOIN Reservation as R "
    f"WHERE G.first_name || G.last_name LIKE \'%{name}%\'")
    for idx,row in enumerate(db.query(query)):
      if row:
        table.append([idx+1]+list(row.values()))
    print(tabulate(table,headers=["Row ID","Guest First Name","Guest Last Name", "Room Number", "Check-In", "Check-out"],tablefmt="pretty"))
    choice = int(input("Please select row number: "))
    


  #exec_menu(choice)
  return

def menu8():
  os.system('clear')
  print('Daily report')
  print('Nothing to report today')
  print('9. Back')
  print('0. Exit')
  choice = input(' >> ')
  exec_menu(choice)
  return

def back():
  menu_actions['main_menu']()

def exit():
  print('Exiting the program...')
  sys.exit()

menu_actions = {
  'main_menu' : main_menu,
  '1' : menu1,
  '2' : menu2,
  '3' : menu3,
  '4' : menu4,
  '5' : menu5,
  '6' : menu6,
  '7' : menu7,
  '8' : menu8,
  '9' : back,
  '0' : exit,
}

if __name__ == "__main__":
  main_menu()